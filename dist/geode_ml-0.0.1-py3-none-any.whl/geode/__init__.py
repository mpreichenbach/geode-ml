#__init__.py

# version of the geode package
__version__ = "0.0.1"
